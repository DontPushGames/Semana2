package com.example.dontp.agenda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConfirmarContacto extends AppCompatActivity {

    private TextView _nombre;
    private TextView _telefono;
    private TextView _mail;
    private TextView _descripcion;
    private TextView _fecha;

    private String sNombre;
    private String sTelefono;
    private String sMail;
    private String sDescripcion;
    private String sFecha;

    private Button editButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmar_contacto);

        Bundle extras = getIntent().getExtras();

        _nombre = (TextView) findViewById(R.id._nombre);
        _telefono = (TextView)findViewById(R.id._telefono);
        _mail = (TextView)findViewById(R.id._mail);
        _descripcion = (TextView)findViewById(R.id._descrip);
        _fecha = (TextView)findViewById(R.id._fecha);

        sNombre = extras.getString("nombreCntc");
        sTelefono = extras.getString("teleCntc");
        sMail = extras.getString("mailCntc");
        sDescripcion = extras.getString("descripcionCntc");
        sFecha = extras.getString("fechaCntc");


        _nombre.setText(sNombre);
        _fecha.setText(sFecha);
        _telefono.setText(sTelefono);
        _mail.setText(sMail);
        _descripcion.setText(sDescripcion);

        editButton = (Button)findViewById(R.id.edit_button);

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(ConfirmarContacto.this,MainActivity.class);


                startActivity(intent);
            }
        });

    }
}
