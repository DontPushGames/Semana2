package com.example.dontp.agenda;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private Button btnSiguiente;

    private TextInputEditText nombreEditText;
    private TextInputEditText telEditText;
    private TextInputEditText mailEditText;
    private TextInputEditText descripcionEditText;

    private TextInputLayout nombreL;
    private TextInputLayout telL;
    private TextInputLayout mailL;
    private TextInputLayout descripcionL;

    private RelativeLayout mainLayout;

    private DatePicker datePicker;

    private String bornDate;
    private int day;
    private int month;
    private int year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        mainLayout = (RelativeLayout)findViewById(R.id.mainLayout);
        mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager inputManager = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        });

        btnSiguiente = (Button)findViewById(R.id.buttonSiguiente);
        nombreEditText = (TextInputEditText)findViewById(R.id.nombreInput);
        telEditText = (TextInputEditText)findViewById(R.id.telInput);
        mailEditText = (TextInputEditText)findViewById(R.id.mailInput);
        descripcionEditText = (TextInputEditText)findViewById(R.id.dscptnInput);

        nombreL = (TextInputLayout)findViewById(R.id.nombreL) ;
        nombreL.setHintAnimationEnabled(true);

        telL = (TextInputLayout)findViewById(R.id.telL) ;
        telL.setHintAnimationEnabled(true);

        mailL = (TextInputLayout)findViewById(R.id.mailL) ;
        mailL.setHintAnimationEnabled(true);

        descripcionL = (TextInputLayout)findViewById(R.id.dscptnL) ;
        descripcionL.setHintAnimationEnabled(true);

        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                datePicker = (DatePicker) findViewById(R.id.datePicker);
                day = datePicker.getDayOfMonth();
                month = datePicker.getMonth() + 1;
                year = datePicker.getYear();

                bornDate = day + "/" + month + "/" + year;
                Intent intent = new Intent(MainActivity.this,ConfirmarContacto.class);

                intent.putExtra("nombreCntc",nombreEditText.getText().toString());
                intent.putExtra("teleCntc",telEditText.getText().toString());
                intent.putExtra("mailCntc",mailEditText.getText().toString());
                intent.putExtra("descripcionCntc",descripcionEditText.getText().toString());
                intent.putExtra("fechaCntc",bornDate.toString());

                startActivity(intent);
            }
        });
    }
}
